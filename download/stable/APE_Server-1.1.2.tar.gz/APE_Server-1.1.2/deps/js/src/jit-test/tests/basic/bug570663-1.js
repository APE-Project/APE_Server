// don't crash
for (var a = 0; a < 4; a++) {
  switch (NaN) {}
}
