// don't crash
gczeal(2)
evalcx('split')

