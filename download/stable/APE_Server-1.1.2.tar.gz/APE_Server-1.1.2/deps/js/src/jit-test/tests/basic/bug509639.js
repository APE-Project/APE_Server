// don't crash

(function(){ var c; eval("for(c in [1,2,3,4]) {}") })();
