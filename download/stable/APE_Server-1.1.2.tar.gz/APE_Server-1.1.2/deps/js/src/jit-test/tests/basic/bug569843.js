x = <x/>;
for each(l in [0, 0, 0, 0]) {
    delete x.d;
}
