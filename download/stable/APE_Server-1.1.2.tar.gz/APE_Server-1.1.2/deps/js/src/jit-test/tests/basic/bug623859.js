// |jit-test| allow-oom

(function() {
   Iterator((function() {
           switch ((7)) {
               default:
                     return (Float32Array).call([], 4300018)
                         case Proxy.create((function() {
                                     return {
                                               e:
                                                         function() {}
                                                                 }
                                                                       })):
                             }
                               })())
   })()
