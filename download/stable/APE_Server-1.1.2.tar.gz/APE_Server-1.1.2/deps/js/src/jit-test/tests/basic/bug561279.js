{
    let y;
    eval('eval("for (z = 0; z < 6; z++) a = z;")');
}
