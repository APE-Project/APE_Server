var a = [];
for (var i = 0; i < RUNLOOP; i++)
    a[i] = 0;
var b = #1=[x === "0" && (#1#.slow = 1) for (x in a)];
assertEq(b[0], 1);
for (var i = 1; i < RUNLOOP; i++)
    assertEq(b[i], false);
