var x = Uint32Array();
for (var i = 0; i < 100; i++)
    x[77] = x[77];

// Don't assert.
