x = <x/>
for (var z = 0; z < 4; z++) {
    print(x.z)
}
