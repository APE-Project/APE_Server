{
      function a() {}
}
Math.floor(Math.d)
  function c() {}
  c()
  for each(let b in [0, 0, 0, 0, 0, 0, 0, -2147483648]) {
        print(Math.abs(b))
  }

// Don't assert
