for (var j = 0; j < 9; j++) {
    var a = j;
    var b = this.a;
}
assertEq(b, 8);
