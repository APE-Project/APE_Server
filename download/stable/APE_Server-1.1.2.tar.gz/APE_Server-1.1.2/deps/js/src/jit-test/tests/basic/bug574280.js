for (p = 0; p < 4; p++) {
  a = 0
  new XMLList
}
