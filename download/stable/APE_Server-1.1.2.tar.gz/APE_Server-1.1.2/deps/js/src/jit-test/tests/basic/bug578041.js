this.__defineGetter__('x', Float32Array);
with(this)
    x;
