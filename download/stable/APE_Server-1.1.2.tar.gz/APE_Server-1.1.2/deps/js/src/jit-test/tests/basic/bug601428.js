// |jit-test| error: SyntaxError;
let({}=[c for(x in[])]){let
