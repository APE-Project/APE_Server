'use strict';
eval("var i = 0; var end = RUNLOOP; for(var j = 0; j < end; i++, j++) { i = 0; }");
print("done");
