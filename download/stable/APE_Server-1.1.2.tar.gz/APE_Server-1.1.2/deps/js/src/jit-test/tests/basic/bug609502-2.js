for (var i = 0; i < RUNLOOP; i++) {
    Math.abs(-2147483648)
}

// Don't assert
