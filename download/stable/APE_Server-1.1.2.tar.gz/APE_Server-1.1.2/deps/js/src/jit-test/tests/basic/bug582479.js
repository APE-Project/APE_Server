for (b = 0; b < 2; b++) {
    / /
    (function(){})
}

