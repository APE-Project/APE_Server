var array = new Array(4294967295);
for (var j = 0; j < RUNLOOP; ++j) { '' + array.length; }

// Don't assert.

