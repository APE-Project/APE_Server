function a(bb) {
    "use strict";
    return;
    this.d = function() { bb; };
}
for (var i = 0; i <= RUNLOOP; i++)
    a();
