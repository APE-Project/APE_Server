// don't crash or assert

+Function("switch(\"\"){case 1:case 8:}");