try {
    for (var j = 0; j < 2; ++j) {
        if (j == 1) {
            ++(null[2]);
        }
    }
} catch(e) {
}
