
for (a = 0; a < 4; a++) {
    new Math.round(0).t
}

/* Don't assert. */

