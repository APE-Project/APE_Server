for(var i = 0; i < RUNLOOP; i++) {
      x = ''.charCodeAt(NaN);
}

for(var i = 0; i < RUNLOOP; i++) {
      x = ''.charAt(NaN);
}

// Don't assert
