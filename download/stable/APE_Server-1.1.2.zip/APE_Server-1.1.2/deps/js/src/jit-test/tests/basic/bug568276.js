function outer(a) { var b, c, d, e, f, g, h, i; function a() {} }
