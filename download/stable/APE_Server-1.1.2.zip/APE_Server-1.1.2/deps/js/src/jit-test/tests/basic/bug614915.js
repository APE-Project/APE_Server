var s = [undefined, undefined].sort();
assertEq(s.length, 2);
