function FPQuadCmp()
{
    for (let j = 0; j < 3; ++j) { true == 0; }
    return "ok";
}
assertEq(FPQuadCmp(), "ok");
