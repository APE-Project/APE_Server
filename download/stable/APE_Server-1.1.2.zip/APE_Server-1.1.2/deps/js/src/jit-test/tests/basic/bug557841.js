eval("for(a = 0; a < 4; a++) x = 1;", []);
