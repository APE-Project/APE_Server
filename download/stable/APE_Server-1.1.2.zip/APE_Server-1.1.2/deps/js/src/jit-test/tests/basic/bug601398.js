(function () {
    try {} finally {
        let(z) {
            return;
        }
    }
})()
