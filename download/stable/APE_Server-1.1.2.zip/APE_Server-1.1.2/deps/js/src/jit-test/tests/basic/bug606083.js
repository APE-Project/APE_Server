// vim: set ts=4 sw=4 tw=99 et:
function f(L) {
    do {
     L: for (var i = 0; i < L; i++) {
            break L;
        }
    } while (0);
}
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
f(1);
